# Paket evaluasi otomatis Music IR

Buka LAPORAN_EVALUASI_RELEVANSI.md untuk hasil, penyebut, dan keterbatasan. TEKS_SIAP_LAPORAN.md dapat dipakai sebagai paragraf metode. exports/ memuat qrels otomatis, label, semua metrik per query dan agregat. Tidak diperlukan review manusia untuk ekspor ini; hasil tidak diklaim sebagai ground truth manusia.

Pipeline retrieval dan parameter dibekukan. Hasil merupakan evaluasi hibrida: tema dinilai agent LLM dari lirik penuh; katalog/kutipan/audio memakai proksi pemeriksaan corpus yang dinyatakan terpisah. Null tetap tidak diketahui dan bukan label0. Tes fungsional bukan metrik relevansi.

semantic_judgments/ berisi keputusan agent dan kutipan pendek. semantic_input_hashes.json mencatat seluruh input penilaian dan hash sumber. Full corpus.json, semantic_packets/ (lirik lengkap), state.sqlite3, model, cache, environment, credential, node_modules dan virtual environment sengaja tidak disertakan. Berkas input lengkap tetap tersedia dalam folder run lokal yang disebut manifest; verifikasi ulang lirik memerlukan snapshot corpus tersebut. Tidak ada tautan input yang seolah berkas lengkapnya disertakan di ZIP ini.

label_data_errata.json mempertahankan label sebelum/sesudah koreksi field berisi placeholder editor. validation/ menyimpan log eksekusi tes, bukti pipeline tidak berubah, dan tangkapan layar aplikasi asli. Pengujian Elasticsearch dilewati apabila flag pengujian integrasi tidak diaktifkan; backend retrieval run ini adalah local.

source/ adalah snapshot kode evaluasi dan antarmuka untuk pemeriksaan. Menjalankan ulang penilaian LLM dapat menghasilkan perbedaan; model/revision persis, sampling, token dan biaya sesi tidak diekspos. Paket tidak mengarang nilainya. Untuk menghitung ulang label deterministik/metric gunakan kode tersebut dengan snapshot data lokal; jangan mengubah rubrik berdasarkan skor.
