# Laporan evaluasi otomatis Music IR

Run `relevance_20261122T203100_WIB_automatic`. **Review manusia tidak diwajibkan untuk ekspor ini.** Hasil merupakan evaluasi otomatis hibrida: penilaian makna lirik oleh agent LLM dan pemeriksaan objektif metadata, kutipan, serta angka corpus. Label bukan hasil penilaian manusia dan tidak boleh dinyatakan sebagai akurasi berbasis ground truth manusia.

## Snapshot dan cakupan

Corpus: `2708d05f6486650d00bec7db689c2672b61829952f8a9b22ec2c3c9755402758`; query: `2941c25ad01bc1d305266ff1c64058ac9d21fa71a27b19ec2a895232bf808ec3`; pipeline: `1dc18ed5bf735e4ff33917d7492b57c7c71f18006f80480f6e9663c54e01578b`. Seluruh query asli, split, corpus, config, metode, bobot, top-k dan batas kandidat dipertahankan. Ranking/pool digunakan ulang dari `relevance_20261122T194000_WIB`. Tidak ada tuning atau pemilihan query berdasarkan skor evaluasi.

Terdapat 160 query dan 960 ranking dari E1–E5/AUTO. Pool utama berkedalaman100 berisi 24367 pasangan unik. Tema AUTO tetap maksimum24; hasil serupa tidak dimasukkan. Query gagal atau tidak mempunyai relevan diketahui tetap ada pada CSV, tidak dihapus diam-diam.

Otomatis diproses: **24367/24367**; berlabel numerik: **24297**; belum terselesaikan: **70**; belum diproses: **0**. Status eksekusi: **complete_processing**. Semua judgment terselesaikan: **False**. Istilah needs_review pada penyimpanan lama berarti bukti otomatis belum cukup; tidak menjadi kewajiban review manusia untuk ekspor ini. Nilainya tetap null.

## Asal label dan pedoman

Distribusi asal label: `{"Deterministic corpus artist evidence check": 3653, "Deterministic corpus audio evidence check": 4680, "Deterministic corpus lyrics evidence check": 6587, "LLM full-lyric thematic judgment": 4768, "Deterministic corpus title evidence check": 4679}`. Distribusi grade: `{"0": 16784, "3": 5274, "null": 70, "2": 748, "1": 1491}`.

Skala:3 kebutuhan inti jelas terpenuhi,2 cukup terpenuhi,1 terkait sebagian/lemah,0 tidak memenuhi kebutuhan inti. Ketidakpastian/data hilang=null. Penilaian tema mengacu pada makna penuh lirik dan facet query (misalnya jarak geografis, bukan sekadar jarak emosional). Lirik diberikan lengkap dengan kamus baris yang dapat direkonstruksi tanpa kehilangan teks; urutan serta pengulangan tetap tersedia. Bukti, reason, hash input dan respons agent mentah disimpan. Nama mode, skor, posisi asal, hint ID, dan alasan retrieval tidak diberikan kepada agent.

Katalog dan angka objektif diperiksa dengan kode independen dari output retrieval; ini diberi asal **deterministic checks**, bukan diklaim inferensi LLM. Kutipan lirik menggunakan pencarian literal dan edit terbatas atas seluruh lirik, sehingga hasil kategori ini adalah proksi kecocokan teks. Soft audio high/low memakai rubrik persentil yang ditetapkan sebelum melihat metrik; ini selaras dengan preferensi fitur retrieval sehingga bukan validasi independen metode audio. Genre playlist dan angka audio tidak diperlakukan sebagai kebenaran tema/emosi.

Query happy yang ambigu dioperasionalkan sebagai makna lirik bahagia, bukan persepsi bunyi; interpretasi otomatis ini dicatat pada automatic_rubric.json, bukan persetujuan manusia. Pedoman dibekukan sebelum penilaian/metrik; tidak diubah agar AUTO/E5 memperoleh skor lebih tinggi.

Penilai paralel yang benar-benar digunakan:

```json
{
  "provider": "OpenAI Codex direct sessions with user-authorized subagents",
  "exact_model": null,
  "model_revision": null,
  "sampling_parameters": null,
  "usage_tokens": null,
  "cost": null,
  "user_authorization": "Ya, gunakan beberapa agent penilai otomatis",
  "agents": {
    "worker_1": "/root/semantic_judge_1",
    "worker_2": "/root/semantic_judge_2",
    "worker_3": "/root/semantic_judge_3"
  },
  "scope": "LLM thematic labels only; objective checks are separately identified as deterministic corpus checks",
  "original_semantic_query_catalog": "semantic_query_contexts.json",
  "supplementary_judge": {
    "agent": "/root",
    "provider": "openai-codex-session-root",
    "batches": {
      "worker_3": [
        17,
        18
      ]
    },
    "method": "Direct full-lyric reading with original query catalog and frozen rubric"
  }
}
```

Provider penilaian tema adalah sesi agent OpenAI Codex; model/revision tepat, parameter sampling, token dan biaya tidak diekspos sehingga tidak dikarang. Label pemeriksaan objektif tidak memakai model. Human review records=0; human_grade/final_grade tidak diisi atas nama pengguna.

Dokumen tema dibagi antartiga agent, dengan tambahan pembacaan langsung oleh assistant induk untuk batch017–018 worker3. Satu dokumen memakai satu profil penilaian yang disimpan; tidak dilakukan pelabelan silang independen, pengukuran kesepakatan antarpenilai, atau adjudikasi manusia. Profil per tema dipakai kembali untuk pasangan query Indonesia/Inggris yang berada dalam group_id kebutuhan yang sama. Pasangan tersebut bukan penilaian independen yang terpisah.

## Definisi metrik dan ketidakpastian

nDCG@10: gain=2^grade−1, discount=log2(rank+1). MRR@10 dan Recall@100: relevan biner grade≥2. Recall dihitung terhadap dokumen relevan yang **diketahui dalam qrels pool**, bukan semua dokumen relevan corpus. Ranking selalu hasil utama; daftar yang lebih pendek tidak dipanjang-panjangkan.

Qrels tidak mengubah null menjadi grade0. Untuk estimasi known-qrels, dokumen unjudged pada ranking tidak menyumbang gain/relevan, sesuai konvensi evaluasi yang dinyatakan; ini bukan keputusan bahwa dokumen tersebut tidak relevan. Query dengan label belum terselesaikan ditandai provisional_unjudged dan cakupan judged@10 diekspor. Bias akibat judgment hilang tetap mungkin. Jika IDCG diketahui nol, nDCG=null; bila tidak ada grade≥2 diketahui, MRR/Recall=null. Macro hanya merata-ratakan nilai terdefinisi, dengan penyebut per metrik terlihat pada tabel/JSON. Angka bukan hasil validasi manusia atau jaminan generalisasi.

Query dengan metrik yang tidak terdefinisi tetap disimpan pada seluruh enam baris mode:

| Query ID | Query asli | Label diketahui | Unresolved | Relevan biner diketahui |
| --- | --- | --- | --- | --- |
| lyrics-030 | lirik "i m cryin for i don t think" | 212 | 1 | 0 |

## Hasil agregat otomatis

| Mode | nDCG@10 | MRR@10 | Recall@100 known pool | n query nDCG/MRR/Recall |
| --- | --- | --- | --- | --- |
| E1 | 0.6223 | 0.6547 | 0.6620 | 159/159/159 |
| E2 | 0.5142 | 0.5443 | 0.6409 | 159/159/159 |
| E3 | 0.5818 | 0.6406 | 0.7611 | 159/159/159 |
| E4 | 0.5317 | 0.5758 | 0.7611 | 159/159/159 |
| E5 | 0.7253 | 0.7739 | 0.8992 | 159/159/159 |
| AUTO | 0.8930 | 0.9443 | 0.7775 | 159/159/159 |

## Hasil per kategori

| Kategori | Mode | nDCG@10 | MRR@10 | Recall@100 known pool | n query nDCG/MRR/Recall | Cakupan judged@10 |
| --- | --- | --- | --- | --- | --- | --- |
| title | E1 | 0.9443 | 0.9245 | 1.0000 | 32/32/32 | 1.0000 |
| title | E2 | 1.0000 | 1.0000 | 1.0000 | 32/32/32 | 1.0000 |
| title | E3 | 1.0000 | 1.0000 | 1.0000 | 32/32/32 | 1.0000 |
| title | E4 | 1.0000 | 1.0000 | 1.0000 | 32/32/32 | 1.0000 |
| title | E5 | 1.0000 | 1.0000 | 1.0000 | 32/32/32 | 1.0000 |
| title | AUTO | 0.9933 | 1.0000 | 0.9844 | 32/32/32 | 1.0000 |
| artist | E1 | 0.9897 | 0.9844 | 1.0000 | 32/32/32 | 1.0000 |
| artist | E2 | 0.9969 | 1.0000 | 1.0000 | 32/32/32 | 1.0000 |
| artist | E3 | 0.9918 | 1.0000 | 1.0000 | 32/32/32 | 1.0000 |
| artist | E4 | 0.9971 | 1.0000 | 1.0000 | 32/32/32 | 1.0000 |
| artist | E5 | 0.9971 | 1.0000 | 1.0000 | 32/32/32 | 1.0000 |
| artist | AUTO | 1.0000 | 1.0000 | 1.0000 | 32/32/32 | 1.0000 |
| lyrics | E1 | 0.9643 | 0.9516 | 1.0000 | 31/31/31 | 1.0000 |
| lyrics | E2 | 0.3628 | 0.3141 | 0.9355 | 31/31/31 | 0.9969 |
| lyrics | E3 | 0.4532 | 0.3834 | 0.9355 | 31/31/31 | 0.9906 |
| lyrics | E4 | 0.2833 | 0.2399 | 0.9355 | 31/31/31 | 0.9938 |
| lyrics | E5 | 0.2833 | 0.2399 | 0.9355 | 31/31/31 | 0.9938 |
| lyrics | AUTO | 0.9032 | 0.9032 | 0.9032 | 31/31/31 | 1.0000 |
| semantic | E1 | 0.1858 | 0.4069 | 0.2579 | 32/32/32 | 1.0000 |
| semantic | E2 | 0.1630 | 0.3688 | 0.2156 | 32/32/32 | 1.0000 |
| semantic | E3 | 0.4223 | 0.7961 | 0.8131 | 32/32/32 | 0.9938 |
| semantic | E4 | 0.3325 | 0.6130 | 0.8131 | 32/32/32 | 0.9969 |
| semantic | E5 | 0.3325 | 0.6130 | 0.8131 | 32/32/32 | 0.9969 |
| semantic | AUTO | 0.5686 | 0.8170 | 0.2553 | 32/32/32 | 1.0000 |
| audio | E1 | 0.0383 | 0.0156 | 0.0625 | 32/32/32 | 1.0000 |
| audio | E2 | 0.0438 | 0.0312 | 0.0625 | 32/32/32 | 1.0000 |
| audio | E3 | 0.0379 | 0.0156 | 0.0625 | 32/32/32 | 1.0000 |
| audio | E4 | 0.0379 | 0.0156 | 0.0625 | 32/32/32 | 1.0000 |
| audio | E5 | 1.0000 | 1.0000 | 0.7484 | 32/32/32 | 1.0000 |
| audio | AUTO | 1.0000 | 1.0000 | 0.7484 | 32/32/32 | 1.0000 |

Kategori semantic merupakan penilaian makna lirik oleh LLM. Kategori title, artist, lyrics dan audio merupakan proksi pemeriksaan corpus; angka agregat gabungan mewarisi perbedaan sumber tersebut. Bandingkan setiap kategori bersama pedomannya, bukan menyebut keseluruhan tabel sebagai akurasi semantik.

## Hasil per split yang dibekukan

| Split | Mode | nDCG@10 | MRR@10 | Recall@100 known pool | n query nDCG/MRR/Recall |
| --- | --- | --- | --- | --- | --- |
| dev | E1 | 0.6019 | 0.6188 | 0.6492 | 40/40/40 |
| dev | E2 | 0.5340 | 0.5557 | 0.6292 | 40/40/40 |
| dev | E3 | 0.5951 | 0.6113 | 0.7379 | 40/40/40 |
| dev | E4 | 0.5547 | 0.5792 | 0.7379 | 40/40/40 |
| dev | E5 | 0.7547 | 0.7792 | 0.8999 | 40/40/40 |
| dev | AUTO | 0.9041 | 0.9500 | 0.8102 | 40/40/40 |
| test | E1 | 0.6292 | 0.6668 | 0.6662 | 119/119/119 |
| test | E2 | 0.5076 | 0.5404 | 0.6448 | 119/119/119 |
| test | E3 | 0.5774 | 0.6505 | 0.7689 | 119/119/119 |
| test | E4 | 0.5240 | 0.5747 | 0.7689 | 119/119/119 |
| test | E5 | 0.7155 | 0.7722 | 0.8989 | 119/119/119 |
| test | AUTO | 0.8892 | 0.9424 | 0.7665 | 119/119/119 |

Label test adalah nama split draft yang dipertahankan. Query memiliki paparan regresi/pengembangan sehingga angka test ini tidak membuktikan generalisasi pada test independen.

## Berkas bukti dan ekspor

Ekspor versi ini: `exports/20261122T141456Z_475cbb61`. auto_labels.jsonl memuat grade, asal, alasan, bukti, flags, dan identitas input. qrels_auto.tsv berisi grade numerik saja; unresolved_pairs.csv menyimpan nilai yang tetap tidak diketahui. metrics_auto_per_query.csv menyimpan seluruh 960 baris query-mode dan cakupan; metrics_auto_summary.json memuat semua penyebut dan kebijakan. semantic_packets/ dan semantic_judgments/ menyimpan input lengkap dan keputusan LLM yang dapat diperiksa. objective_method.json dan automatic_rubric.json menyatakan prosedur pemeriksaan otomatis.

Koreksi validasi data, bila ada, dicatat pada label_data_errata.json beserta label sebelum/sesudah. Satu field corpus berisi petunjuk editor lirik, bukan lirik lagu; label kutipan yang terdampak dikoreksi menjadi null sesuai aturan data tidak cukup. Corpus, ranking, dan rubrik tetap dipertahankan.

Tidak dibuat qrels_final.tsv seolah-olah berlabel manusia. Semua ekspor dapat dipakai langsung sebagai **hasil evaluasi otomatis**, dengan keterangan sumber dan keterbatasan ini tetap dicantumkan. Jangan mengganti istilahnya menjadi ground truth manusia, benchmark independen, atau akurasi pencarian yang telah divalidasi manusia.

## Teks singkat siap dimasukkan ke laporan

Evaluasi dilakukan otomatis pada 160 query dengan pool 24367 pasangan query–lagu, yang dibentuk dari hasil utama hingga peringkat100 pada enam konfigurasi retrieval. Pipeline dan parameternya dibekukan. Penilaian tema didasarkan pada pembacaan lirik oleh agent LLM; tugas metadata, kutipan literal, dan batas audio memakai pemeriksaan corpus yang dinyatakan sebagai proksi otomatis. Nilai relevansi menggunakan skala0–3 dan ambang relevan biner≥2. Metrik yang dilaporkan adalah nDCG@10, MRR@10, serta Recall@100 terhadap relevan yang diketahui pada pool. Tidak ada penilaian manusia; karena itu hasil menunjukkan kesesuaian terhadap prosedur penilaian otomatis ini dan tidak membuktikan efektivitas berbasis ground truth manusia. Label yang tidak dapat ditetapkan tetap null dan cakupan judgment dilaporkan.
