"""Music information retrieval prototype."""
