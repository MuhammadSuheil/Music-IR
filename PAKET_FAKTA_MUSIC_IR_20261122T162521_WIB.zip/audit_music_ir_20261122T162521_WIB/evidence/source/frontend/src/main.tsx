import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './styles.css'
import './research.css'
import './mood.css'
import './search.css'

ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>)
